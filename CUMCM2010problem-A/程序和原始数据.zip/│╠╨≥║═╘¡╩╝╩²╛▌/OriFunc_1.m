clear all;
format short g
a=0.89;
b=0.6;
l=2.45;
h=xlsread('E:\Oil_Daily_Volume_Info.xls','Input_Horizonal','D2:D79')/1000;
y=xlsread('E:\Oil_Daily_Volume_Info.xls','Input_Horizonal','C2:C79')+262;
f=a/b*l.*((h-b).*sqrt(h.*(2*b-h))+b^2*asin(h./b-1)+0.5*pi*b^2).*1000
xlswrite('E:\Oil_Daily_Volume_Info.xls',f-y,'Input_Horizonal','I2:I79');