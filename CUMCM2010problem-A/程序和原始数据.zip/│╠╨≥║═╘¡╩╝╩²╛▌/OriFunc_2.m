clear all;
format short g

a=0.89;
b=0.6;
L=2.45;
L1=0.4;
alpha=4.1/180*pi;
D=1.2;
VolL=2.45;
VolH2=1.2;

H1=xlsread('E:\Oil_Daily_Volume_Info.xls','Input_Tilt','D2:D54')/1000;
y=xlsread('E:\Oil_Daily_Volume_Info.xls','Input_Tilt','C2:C54')+215;

for m=1:51 
if H1(m)>=(L-L1)*tan(alpha) & H1(m)<=D-L1*tan(alpha)
    N=H1(m)+L1*tan(alpha);
    H2=N-1/2*L*tan(alpha);
    DelV(m)=a/b*L*((H2-b)*sqrt(H2*(2*b-H2))+b^2*asin(H2/b-1)+0.5*pi*b^2)*1000;
end
if H1(m)>=0 & H1(m)<=(L-L1)*tan(alpha)
    N=H1(m)+L1*tan(alpha);
    H2=1/2*N;
    Lpos=N*cot(alpha);
    DelV(m)=a/b*Lpos*((H2-b)*sqrt(H2*(2*b-H2))+b^2*asin(H2/b-1)+0.5*pi*b^2)*1000;
end
if H1(m)>=D-L1*tan(alpha) & H1(m)<=D
    N=D-H1(m)+(L-L1)*tan(alpha);
    H2=1/2*N;
    Lpos=N*cot(alpha);
    V=a/b*Lpos*((H2-b)*sqrt(H2*(2*b-H2))+b^2*asin(H2/b-1)+0.5*pi*b^2)*1000;
    Vol=a/b*VolL*((VolH2-b)*sqrt(VolH2*(2*b-VolH2))+b^2*asin(VolH2/b-1)+0.5*pi*b^2)*1000;
    DelV(m)=Vol-V;
end
m=m+1;
end
xlswrite('E:\Oil_Daily_Volume_Info.xls',DelV-y,'Input_Tilt','I2:I54');