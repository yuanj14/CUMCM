clear all
clc

syms a b h h1 h2 l2

r=1.5;
l1=2;
l=8;
d=3;
h=xlsread('E:\Actual_Oil_Store','Data','E2:E303')/1000;
va=xlsread('E:\Actual_Oil_Store','Data','D2:D303');
iter=1;

xlower=inline('0','y');
xupper=inline('sqrt(1.5^2-y.^2)','y');
fun=inline('sqrt(1.625^2-x.^2-y.^2)-0.625','x','y');

for k=1:3
    switch(k)
        case 1
            amin=20;
            bmin=20;
            vary=20;
            avevary=1;
        case 2
            vary=1;
            avevary=0.1;
        case 3
            vary=0.1;
            avevary=0.01;
    end
    for a=(amin-vary)/180*pi:avevary/180*pi:(amin+vary)/180*pi
        for b=(bmin-vary)/180*pi:avevary/180*pi:(bmin+vary)/180*pi
            V=zeros(302,1);
            for m=1:302
                h1=r+(h(m)-r)*cos(b);
                if h1>=0 & h1<=6*tan(a)            
                    n1=l1*tan(a)+h1;
                    h2=1/2*n1;
                    n2=0;
                    l2=n1*cot(a);                
                    V(m)=2*quad2dggen(fun,xlower,xupper,-1.5,n1-1.5,0.0001)+l2*1.5^2*((h2-1.5)/1.5*sqrt(1-((h2-1.5)/1.5)^2)+asin((h2-1.5)/1.5)+pi/2);
                end
                if h1>6*tan(a) & h1<d-l1*tan(a)
                    n1=l1*tan(a)+h1;
                    h2=n1-l/2*tan(a);
                    n2=n1-l*tan(a);
                    V(m)=2*quad2dggen(fun,xlower,xupper,-1.5,n1-1.5,0.0001)+8*1.5^2*((h2-1.5)/1.5*sqrt(1-((h2-1.5)/1.5)^2)+asin((h2-1.5)/1.5)+pi/2)+2*quad2dggen(fun,xlower,xupper,-1.5,n2-1.5,0.0001);
                end
                if h1>d-l1*tan(a) & h1<=d
                    n1=d;
                    n2=d-h1+6*tan(a);
                    h2=1/2*n2;                
                    l2=n2*cot(a);
                    V(m)=2*quad2dggen(fun,xlower,xupper,-1.5,n1-1.5,0.0001)+8*1.5^2*((3-1.5)/1.5*sqrt(1-((3-1.5)/1.5)^2)+asin((3-1.5)/1.5)+pi/2)-l2*1.5^2*((h2-1.5)/1.5*sqrt(1-((h2-1.5)/1.5)^2)+asin((h2-1.5)/1.5)+pi/2)+2*quad2dggen(fun,xlower,xupper,-1.5,n2-1.5,0.0001);
                end
            end
            
            V=V*1000;
            for n=0:298
                V(300-n)=abs(V(300-n-1)-V(300-n));
            end
            V(1)=60;
            Delta=sum((V-va).*(V-va));
            if iter==1
                minimum=Delta;
                amin=a;
                bmin=b;
            end
            if Delta<minimum
                minimum=Delta;
                amin=a;
                bmin=b;
            end
            iter=iter+1;
        end
    end
end